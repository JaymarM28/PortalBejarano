// export const environment = {
//   production: false,
//   apiUrl: 'http://localhost:3000/api'
// };

export const environment = {
  production: true,
  apiUrl: 'https://portalbejarano.onrender.com/api'
};
